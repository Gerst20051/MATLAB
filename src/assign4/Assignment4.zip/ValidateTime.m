function [validDays, validHours, validMinutes] = ValidateTime( days, hours, minutes )
% This function ValidateTime requires 3 inputes and returns 3 values for
% days, hours, and minutes, and translates them into more appropriate
% values, or outputs an error message.


end